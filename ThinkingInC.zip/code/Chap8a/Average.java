class Average
{
    public static void main(String[] args)
    {
        int num1 = 10;
        int num2 = 23;
        System.out.println("The average is " +
                           (num1+num2)/2.0);
    }
}

